import "./index.css" 


const  Main  = () => (
    
    <div>
   <div className = "main-container">
        <img className = "website-logo" src = "https://res.cloudinary.com/cdac01/image/upload/v1643108167/9cfb09f0c029e1f8c938208a7e278d76_hzypir.gif" alt = "welocme.jpg" />
        <h1 className = "main-heading">WELCOME TO  SDLMUI</h1>
        <h2 className = "main-descrption">Please Register & If you already existing Please Login </h2>
        </div>
    </div>
)
export default Main